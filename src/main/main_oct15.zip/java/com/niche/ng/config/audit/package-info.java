/**
 * Audit specific code.
 */
package com.niche.ng.config.audit;
