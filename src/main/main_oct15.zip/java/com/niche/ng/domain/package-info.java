/**
 * JPA domain objects.
 */
package com.niche.ng.domain;
