/******************************************************************************
 *  Property of Nichehands
 *  Nichehands Confidential Proprietary
 *  Nichehands Copyright (C) 2018 All rights reserved
 *  ----------------------------------------------------------------------------
 *  Date  : 2018/09/02
 *  Target: yarn
 *  -----------------------------------------------------------------------------
 *  File Description    : This file performs MapNurseryWithSectorRepository
 *
 *******************************************************************************/
package com.niche.ng.repository;

import com.niche.ng.domain.MapNurseryWithSector;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data  repository for the MapNurseryWithSector entity.
 *
 * BatchQuantityRepository Extends JpaRepository to handle the CRUD operation and
 * querying the values using keywords.
 */
@SuppressWarnings("unused")
@Repository
public interface MapNurseryWithSectorRepository extends JpaRepository<MapNurseryWithSector, Long>, JpaSpecificationExecutor<MapNurseryWithSector> {
    // Query the list of mapNurseryWithSector using a field nurseryId and status
    public List<MapNurseryWithSector> findByNurseryIdAndStatus(Long nurseryId, Integer status);
    // Query the list of mapNurseryWithSector using a field nurseryId
    public List<MapNurseryWithSector> findByNurseryId(Long nurseryId);
}
