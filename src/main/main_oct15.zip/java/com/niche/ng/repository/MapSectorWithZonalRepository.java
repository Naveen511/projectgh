/******************************************************************************
 *  Property of Nichehands
 *  Nichehands Confidential Proprietary
 *  Nichehands Copyright (C) 2018 All rights reserved
 *  ----------------------------------------------------------------------------
 *  Date  : 2018/09/02
 *  Target: yarn
 *  -----------------------------------------------------------------------------
 *  File Description    : This file performs MapSectorWithZonalRepository
 *
 *******************************************************************************/
package com.niche.ng.repository;

import com.niche.ng.domain.MapSectorWithZonal;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * Spring Data  repository for the MapSectorWithZonal entity.
 *
 * MapSectorWithZonalRepository Extends JpaRepository to handle the CRUD operation and
 * querying the values using keywords.
 */
@SuppressWarnings("unused")
@Repository
public interface MapSectorWithZonalRepository extends JpaRepository<MapSectorWithZonal, Long>, JpaSpecificationExecutor<MapSectorWithZonal> {
    // Query the list of mapSectorWithZonal using a field sectorId and status
    public List<MapSectorWithZonal> findBySectorIdAndStatus(Long sectorId, Integer status);
    // Query the list of mapSectorWithZonal using a field sectorId
    public List<MapSectorWithZonal> findBySectorId(Long sectorId);
}
