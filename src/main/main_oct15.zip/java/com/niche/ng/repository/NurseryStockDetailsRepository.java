/******************************************************************************
 *  Property of Nichehands
 *  Nichehands Confidential Proprietary
 *  Nichehands Copyright (C) 2018 All rights reserved
 *  ----------------------------------------------------------------------------
 *  Date  : 2018/08/02
 *  Target: yarn
 *  -----------------------------------------------------------------------------
 *  File Description    : This file performs NurseryStockDetailsRepository
 *
 *******************************************************************************/
package com.niche.ng.repository;

import com.niche.ng.domain.NurseryStockDetails;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data  repository for the NurseryStockDetails entity.
 *
 * NurseryStockDetailsRepository Extends JpaRepository to handle the CRUD operation and
 * querying the values using keywords.
 */
@SuppressWarnings("unused")
@Repository
public interface NurseryStockDetailsRepository extends JpaRepository<NurseryStockDetails, Long>, JpaSpecificationExecutor<NurseryStockDetails> {

    // Query the list of nurseryStockDetails using a field nurseryStockId.
    List<NurseryStockDetails> findByNurseryStockId(Long nurseryStockId);

    // Query the list of nurseryStockDetails using a field itNurseryId.
    List<NurseryStockDetails> findByItNurseryId(Long itNurseryId);

    // Query the list of nurseryStockDetails using a field status.
    List<NurseryStockDetails> findByStatus(Integer status);
}
