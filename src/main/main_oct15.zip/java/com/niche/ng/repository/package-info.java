/**
 * Spring Data JPA repositories.
 */
package com.niche.ng.repository;
