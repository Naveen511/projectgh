/**
 * Spring Security configuration.
 */
package com.niche.ng.security;
