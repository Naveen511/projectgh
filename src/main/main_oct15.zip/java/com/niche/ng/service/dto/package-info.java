/**
 * Data Transfer Objects.
 */
package com.niche.ng.service.dto;
