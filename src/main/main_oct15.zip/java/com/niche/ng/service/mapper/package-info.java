/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.niche.ng.service.mapper;
