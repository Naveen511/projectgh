/**
 * Service layer beans.
 */
package com.niche.ng.service;
