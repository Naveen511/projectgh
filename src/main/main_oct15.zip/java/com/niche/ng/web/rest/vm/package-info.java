/**
 * View Models used by Spring MVC REST controllers.
 */
package com.niche.ng.web.rest.vm;
